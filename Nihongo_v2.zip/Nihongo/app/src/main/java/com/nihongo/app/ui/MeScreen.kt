@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nihongo.app.AppGraph
import com.nihongo.app.R

@Composable
fun MeScreen() {
    val store = AppGraph.store
    val cs = MaterialTheme.colorScheme
    val lessons = AppGraph.allLessons
    val done = lessons.count { store.isDone(it.id) }
    val vocabDone = lessons.filter { it.type == "vocab" && store.isDone(it.id) }.sumOf { it.items.size }
    val kanjiDone = lessons.filter { it.type == "kanji" && store.isDone(it.id) }.sumOf { it.items.size }
    val grammarDone = lessons.filter { it.type == "grammar" && store.isDone(it.id) }.sumOf { it.items.size }
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Me", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        Panel(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Progress", fontSize = 13.sp, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("$done / ${lessons.size} lessons", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (lessons.isEmpty()) 0f else done.toFloat() / lessons.size },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
                Spacer(Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Stat("Day streak", store.streakDays.toString(), Modifier.weight(1f))
                    Stat("Words", vocabDone.toString(), Modifier.weight(1f))
                    Stat("Kanji", kanjiDone.toString(), Modifier.weight(1f))
                    Stat("Grammar", grammarDone.toString(), Modifier.weight(1f))
                }
            }
        }

        Panel(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    "Meaning language",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 4.dp)
                )
                LangRow("en", "English")
                HorizontalDivider(color = cs.outlineVariant)
                LangRow("bn", "বাংলা")
                HorizontalDivider(color = cs.outlineVariant)
                LangRow("both", "English + বাংলা")
            }
        }

        OutlinedButton(
            onClick = { confirmReset = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Reset progress")
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Nihongo", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text("JLPT N5 course · version 2.0", fontSize = 12.sp, color = cs.onSurfaceVariant)
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset progress?") },
            text = { Text("All finished lessons and your streak will be cleared.") },
            confirmButton = {
                TextButton(onClick = {
                    store.reset()
                    confirmReset = false
                }) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Column(modifier = modifier) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LangRow(key: String, label: String) {
    val store = AppGraph.store
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { store.changeLang(key) }
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = store.lang == key, onClick = { store.changeLang(key) })
        Text(label, fontSize = 16.sp)
    }
}
