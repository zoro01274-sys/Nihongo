@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.nihongo.app.AppGraph
import com.nihongo.app.data.QuizGen

@Composable
fun PracticeScreen(nav: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Practice", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "Quick quizzes use the lessons you have finished. If you have not finished any yet, they use everything.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        ActionRow("Vocabulary quiz", "10 questions · words", "語") { nav.navigate("quiz/vocab") }
        ActionRow("Kanji quiz", "10 questions · meaning and reading", "字") { nav.navigate("quiz/kanji") }
        ActionRow("Grammar quiz", "Sentences and fill in the blank", "文") { nav.navigate("quiz/grammar") }
        ActionRow("Hiragana quiz", "Match sound and character", "あ") { nav.navigate("quiz/hira") }
        ActionRow("Katakana quiz", "Match sound and character", "ア") { nav.navigate("quiz/kata") }
        ActionRow("Word list", "Search all ${AppGraph.vocab.size} words", "辞") { nav.navigate("words") }
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String, glyph: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Panel(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(glyph, fontSize = 28.sp, color = cs.primary, modifier = Modifier.width(44.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(subtitle, fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
fun QuickQuizScreen(mode: String, nav: NavController) {
    val store = AppGraph.store
    QuizFlow(
        build = { QuizGen.quick(mode, store.lang) },
        onFinished = { _, _ -> store.touchStreak() },
        onExit = { nav.popBackStack() }
    )
}

@Composable
fun WordsScreen(nav: NavController) {
    var query by remember { mutableStateOf("") }
    val lang = AppGraph.store.lang
    val all = AppGraph.vocab
    val list = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) {
            all
        } else {
            all.filter {
                it.jp.contains(q) || it.kana.contains(q) || it.ro.lowercase().contains(q) ||
                    it.en.lowercase().contains(q) || it.bn.contains(q)
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Word list", onBack = { nav.popBackStack() })
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Search Japanese, romaji, English or Bangla") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        )
        Text(
            "${list.size} words",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp)
        ) {
            items(list) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.jp, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                        Text(
                            if (item.kana != item.jp) "${item.kana}  ·  ${item.ro}" else item.ro,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        MeaningText(item.en, item.bn, lang, size = 14.sp)
                    }
                    SpeakButton(item.kana)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}
