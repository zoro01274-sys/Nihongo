package com.nihongo.app

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nihongo.app.data.Course
import com.nihongo.app.data.Example
import com.nihongo.app.data.Item
import com.nihongo.app.data.Lesson
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.util.Locale

object AppGraph {
    lateinit var store: AppStore
    lateinit var speaker: Speaker
    lateinit var course: Course

    val allLessons: List<Lesson> by lazy { course.units.flatMap { it.lessons } }
    val vocab: List<Item> by lazy {
        allLessons.filter { it.type == "vocab" }.flatMap { it.items }
    }
    val kanji: List<Item> by lazy {
        allLessons.filter { it.type == "kanji" }.flatMap { it.items }
    }
    val examples: List<Example> by lazy {
        allLessons.filter { it.type == "grammar" }.flatMap { lesson -> lesson.items.flatMap { it.ex } }
    }

    fun lesson(id: String): Lesson? = allLessons.firstOrNull { it.id == id }

    fun init(app: Application) {
        store = AppStore(app)
        speaker = Speaker(app)
        val json = Json { ignoreUnknownKeys = true }
        val text = app.assets.open("course_n5.json").bufferedReader().use { it.readText() }
        course = json.decodeFromString(Course.serializer(), text)
    }
}

class AppStore(context: Context) {
    private val sp = context.getSharedPreferences("nihongo_prefs", Context.MODE_PRIVATE)

    var lang by mutableStateOf(sp.getString("lang", "both") ?: "both")
        private set

    var completed by mutableStateOf(parse(sp.getString("completed", "") ?: ""))
        private set

    var streakDays by mutableIntStateOf(0)
        private set

    private var streak = sp.getInt("streak", 0)
    private var lastDay = sp.getLong("lastDay", 0L)

    init {
        streakDays = currentStreak()
    }

    private fun parse(s: String): Map<String, Int> {
        val map = HashMap<String, Int>()
        for (part in s.split(",")) {
            val p = part.split(":")
            if (p.size == 2) map[p[0]] = p[1].toIntOrNull() ?: 0
        }
        return map
    }

    private fun currentStreak(): Int {
        val today = LocalDate.now().toEpochDay()
        return if (lastDay >= today - 1) streak else 0
    }

    fun setLang(value: String) {
        lang = value
        sp.edit().putString("lang", value).apply()
    }

    fun isDone(id: String): Boolean = completed.containsKey(id)

    fun complete(id: String, percent: Int) {
        val old = completed[id] ?: 0
        completed = completed + (id to maxOf(old, percent))
        sp.edit().putString("completed", completed.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
        touchStreak()
    }

    fun touchStreak() {
        val today = LocalDate.now().toEpochDay()
        if (today != lastDay) {
            streak = if (lastDay == today - 1) streak + 1 else 1
            lastDay = today
            sp.edit().putInt("streak", streak).putLong("lastDay", lastDay).apply()
        }
        streakDays = currentStreak()
    }

    fun reset() {
        completed = emptyMap()
        streak = 0
        lastDay = 0L
        streakDays = 0
        sp.edit().remove("completed").remove("streak").remove("lastDay").apply()
    }
}

class Speaker(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var ready = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.JAPAN)
            ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    fun speak(text: String) {
        val clean = text.replace(" ", "").replace("〜", "")
        if (clean.isBlank()) return
        if (!ready) {
            Toast.makeText(
                context,
                "Japanese voice is not available. Install it in your phone's text-to-speech settings.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nihongo")
    }
}
