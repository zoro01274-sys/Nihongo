@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.nihongo.app.AppGraph
import com.nihongo.app.data.KanaChar

@Composable
fun KanaScreen(script: String, nav: NavController) {
    val katakana = script == "katakana"
    val chars = if (katakana) AppGraph.course.kana.katakana else AppGraph.course.kana.hiragana
    val lang = AppGraph.store.lang
    var selected by remember { mutableStateOf<KanaChar?>(null) }

    val basic = chars.filter { it.g == "basic" }
    val dakuten = chars.filter { it.g == "dakuten" }
    val yoon = chars.filter { it.g == "yoon" }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = if (katakana) "Katakana  カタカナ" else "Hiragana  ひらがな",
            onBack = { nav.popBackStack() },
            trailing = {
                TextButton(onClick = { nav.navigate("quiz/" + if (katakana) "kata" else "hira") }) {
                    Text("Practice")
                }
            }
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(15),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("Basic") }
            items(basic, span = { GridItemSpan(3) }) { k -> KanaTile(k) { selected = k } }
            item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("With dakuten and handakuten") }
            items(dakuten, span = { GridItemSpan(3) }) { k -> KanaTile(k) { selected = k } }
            item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("Combination sounds") }
            items(yoon, span = { GridItemSpan(5) }) { k -> KanaTile(k) { selected = k } }
        }
    }

    val k = selected
    if (k != null) {
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = {
                TextButton(onClick = { selected = null }) { Text("Close") }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(k.c, fontSize = 72.sp, color = MaterialTheme.colorScheme.primary)
                    Text(k.r, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    SpeakButton(k.c)
                    if (k.w.isNotBlank()) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                        Text(k.w, fontSize = 24.sp)
                        Text(k.wr, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        MeaningText(k.wm, k.wb, lang, size = 15.sp)
                        SpeakButton(k.w)
                    }
                }
            }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
    )
}

@Composable
private fun KanaTile(k: KanaChar, onClick: () -> Unit) {
    if (k.c.isBlank()) {
        Spacer(Modifier.height(64.dp))
    } else {
        val shape = RoundedCornerShape(12.dp)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(shape)
                .clickable(onClick = onClick),
            shape = shape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(k.c, fontSize = 24.sp)
                Text(k.r, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
