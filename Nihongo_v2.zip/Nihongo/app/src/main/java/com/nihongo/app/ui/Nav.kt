@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab("learn", "Learn", Icons.Default.School),
        Tab("practice", "Practice", Icons.Default.Edit),
        Tab("me", "Me", Icons.Default.Person)
    )

    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo("learn") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = "learn",
            modifier = Modifier.padding(inner)
        ) {
            composable("learn") { LearnScreen(nav) }
            composable("practice") { PracticeScreen(nav) }
            composable("me") { MeScreen() }
            composable(
                "lesson/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { be ->
                LessonScreen(be.arguments?.getString("id") ?: "", nav)
            }
            composable(
                "kana/{script}",
                arguments = listOf(navArgument("script") { type = NavType.StringType })
            ) { be ->
                KanaScreen(be.arguments?.getString("script") ?: "hiragana", nav)
            }
            composable(
                "quiz/{mode}",
                arguments = listOf(navArgument("mode") { type = NavType.StringType })
            ) { be ->
                QuickQuizScreen(be.arguments?.getString("mode") ?: "vocab", nav)
            }
            composable("words") { WordsScreen(nav) }
        }
    }
}
