@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.nihongo.app.AppGraph
import com.nihongo.app.R
import com.nihongo.app.data.CourseUnit
import com.nihongo.app.data.Lesson

@Composable
fun LearnScreen(nav: NavController) {
    val store = AppGraph.store
    val lang = store.lang
    val course = AppGraph.course
    val lessons = AppGraph.allLessons
    val done = lessons.count { store.isDone(it.id) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.logo),
                        contentDescription = null,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Nihongo", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "JLPT N5  ·  $done / ${lessons.size} lessons",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(
                    progress = { if (lessons.isEmpty()) 0f else done.toFloat() / lessons.size },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                KanaCard("あ", "Hiragana", Modifier.weight(1f)) { nav.navigate("kana/hiragana") }
                KanaCard("ア", "Katakana", Modifier.weight(1f)) { nav.navigate("kana/katakana") }
            }
        }

        items(course.units, key = { it.id }) { unit ->
            UnitBlock(unit, nav, lang)
        }
    }
}

@Composable
private fun KanaCard(glyph: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Panel(modifier = modifier, onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(glyph, fontSize = 32.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun UnitBlock(unit: CourseUnit, nav: NavController, lang: String) {
    val store = AppGraph.store
    Column {
        Text(unit.en, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        if (lang != "en" && unit.bn.isNotBlank()) {
            Text(unit.bn, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        Panel(modifier = Modifier.fillMaxWidth()) {
            unit.lessons.forEachIndexed { i, lesson ->
                if (i > 0) {
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 64.dp),
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                }
                LessonRow(lesson, store.isDone(lesson.id), lang) {
                    nav.navigate("lesson/${lesson.id}")
                }
            }
        }
    }
}

@Composable
private fun LessonRow(lesson: Lesson, done: Boolean, lang: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val glyph = when (lesson.type) {
        "vocab" -> "語"
        "kanji" -> "字"
        else -> "文"
    }
    val kind = when (lesson.type) {
        "vocab" -> "Vocabulary · ${lesson.items.size} words"
        "kanji" -> "Kanji · ${lesson.items.size} characters"
        else -> "Grammar · ${lesson.items.size} points"
    }
    val title = if (lang == "bn" && lesson.bn.isNotBlank() && lesson.type != "grammar") lesson.bn else lesson.en
    val sub = if (lang == "both" && lesson.type != "grammar" && lesson.bn.isNotBlank()) {
        "$kind · ${lesson.bn}"
    } else {
        kind
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(if (done) cs.primary else cs.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (done) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = "Completed",
                    tint = cs.onPrimary,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(glyph, fontSize = 14.sp, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = cs.onSurfaceVariant
        )
    }
}
