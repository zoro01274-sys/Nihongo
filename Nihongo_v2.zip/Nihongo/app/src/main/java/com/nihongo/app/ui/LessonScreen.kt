@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.nihongo.app.AppGraph
import com.nihongo.app.data.Item
import com.nihongo.app.data.Lesson
import com.nihongo.app.data.QuizGen

@Composable
fun LessonScreen(id: String, nav: NavController) {
    val lesson = remember(id) { AppGraph.lesson(id) }
    var quiz by remember { mutableStateOf(false) }
    val store = AppGraph.store

    if (lesson == null) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Lesson", onBack = { nav.popBackStack() })
            Text("Lesson not found.", modifier = Modifier.padding(20.dp))
        }
    } else if (!quiz) {
        StudyView(
            lesson = lesson,
            onBack = { nav.popBackStack() },
            onStart = { quiz = true }
        )
    } else {
        QuizFlow(
            build = { QuizGen.forLesson(lesson, store.lang) },
            onFinished = { correct, total ->
                val pct = if (total == 0) 0 else correct * 100 / total
                if (pct >= 60) store.complete(lesson.id, pct) else store.touchStreak()
            },
            onExit = { nav.popBackStack() }
        )
    }
}

@Composable
private fun StudyView(lesson: Lesson, onBack: () -> Unit, onStart: () -> Unit) {
    val lang = AppGraph.store.lang
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(lesson.en, onBack = onBack)
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(lesson.items) { item ->
                when (lesson.type) {
                    "vocab" -> VocabCard(item, lang)
                    "kanji" -> KanjiCard(item, lang)
                    else -> GrammarCard(item, lang)
                }
            }
        }
        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(52.dp)
        ) {
            Text("Start quiz", fontSize = 16.sp)
        }
    }
}

@Composable
private fun VocabCard(item: Item, lang: String) {
    val cs = MaterialTheme.colorScheme
    Panel(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(item.jp, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                if (item.kana != item.jp) {
                    Text(item.kana, fontSize = 15.sp, color = cs.onSurfaceVariant)
                }
                Text(item.ro, fontSize = 13.sp, color = cs.primary)
                Spacer(Modifier.height(6.dp))
                MeaningText(item.en, item.bn, lang)
            }
            SpeakButton(item.kana)
        }
    }
}

@Composable
private fun KanjiCard(item: Item, lang: String) {
    val cs = MaterialTheme.colorScheme
    Panel(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp)) {
            Text(item.jp, fontSize = 56.sp, modifier = Modifier.width(76.dp))
            Column(modifier = Modifier.weight(1f)) {
                MeaningText(item.en, item.bn, lang, size = 17.sp)
                Spacer(Modifier.height(6.dp))
                if (item.onyomi.isNotBlank()) {
                    Text("On: ${item.onyomi}", fontSize = 14.sp, color = cs.onSurfaceVariant)
                }
                if (item.kunyomi.isNotBlank()) {
                    Text("Kun: ${item.kunyomi}", fontSize = 14.sp, color = cs.onSurfaceVariant)
                }
                for (ex in item.ex) {
                    Spacer(Modifier.height(10.dp))
                    HorizontalDivider(color = cs.outlineVariant)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${ex.jp}  (${ex.kana})", fontSize = 17.sp)
                            Text(ex.ro, fontSize = 13.sp, color = cs.primary)
                            MeaningText(ex.en, ex.bn, lang, size = 14.sp)
                        }
                        SpeakButton(ex.kana)
                    }
                }
            }
        }
    }
}

@Composable
private fun GrammarCard(item: Item, lang: String) {
    val cs = MaterialTheme.colorScheme
    Panel(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(item.jp, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
            Spacer(Modifier.height(8.dp))
            MeaningText(item.en, item.bn, lang, size = 15.sp)
            for (ex in item.ex) {
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = cs.outlineVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ex.jp, fontSize = 18.sp)
                        Text(ex.ro, fontSize = 13.sp, color = cs.primary)
                        Spacer(Modifier.height(2.dp))
                        MeaningText(ex.en, ex.bn, lang, size = 14.sp)
                    }
                    SpeakButton(ex.kana)
                }
            }
        }
    }
}
