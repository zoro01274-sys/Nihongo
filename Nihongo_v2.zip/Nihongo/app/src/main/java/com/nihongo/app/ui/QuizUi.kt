@file:OptIn(ExperimentalMaterial3Api::class)

package com.nihongo.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nihongo.app.data.Question

/**
 * Builds the questions, runs the quiz and shows the result.
 * [onFinished] receives (correct, total) once when the quiz ends.
 */
@Composable
fun QuizFlow(
    build: () -> List<Question>,
    onFinished: (Int, Int) -> Unit,
    onExit: () -> Unit
) {
    var round by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val questions = remember(round) { build() }
    val r = result

    if (questions.isEmpty()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Practice", onExit)
            Text("Nothing to practice yet.", modifier = Modifier.padding(20.dp))
        }
    } else if (r == null) {
        QuizRunner(questions, onExit) { correct, total ->
            result = Pair(correct, total)
            onFinished(correct, total)
        }
    } else {
        ResultView(
            correct = r.first,
            total = r.second,
            onRetry = {
                result = null
                round += 1
            },
            onExit = onExit
        )
    }
}

@Composable
fun QuizRunner(
    questions: List<Question>,
    onExit: () -> Unit,
    onDone: (Int, Int) -> Unit
) {
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var correct by remember { mutableIntStateOf(0) }
    val q = questions[index]
    val answered = selected >= 0
    val last = index + 1 >= questions.size

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Default.Close, contentDescription = "Close")
            }
            LinearProgressIndicator(
                progress = { (index + (if (answered) 1 else 0)).toFloat() / questions.size },
                modifier = Modifier
                    .weight(1f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )
            Spacer(Modifier.width(12.dp))
            Text(
                "${index + 1}/${questions.size}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(12.dp))
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            Text(
                q.prompt,
                fontSize = if (q.big) 38.sp else 22.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            if (q.sub.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    q.sub,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
            if (q.speak.isNotBlank()) {
                SpeakButton(q.speak)
            }
            Spacer(Modifier.height(20.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                q.options.forEachIndexed { i, text ->
                    OptionRow(
                        text = text,
                        answered = answered,
                        isCorrect = i == q.answer,
                        isSelected = i == selected,
                        onClick = {
                            if (!answered) {
                                selected = i
                                if (i == q.answer) correct += 1
                            }
                        }
                    )
                }
            }
        }

        Button(
            onClick = {
                if (last) {
                    onDone(correct, questions.size)
                } else {
                    index += 1
                    selected = -1
                }
            },
            enabled = answered,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(52.dp)
        ) {
            Text(if (last) "Finish" else "Continue", fontSize = 16.sp)
        }
    }
}

@Composable
private fun OptionRow(
    text: String,
    answered: Boolean,
    isCorrect: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val container = when {
        answered && isCorrect -> cs.primaryContainer
        answered && isSelected -> cs.errorContainer
        else -> cs.surface
    }
    val borderColor = when {
        answered && isCorrect -> cs.primary
        answered && isSelected -> cs.error
        else -> cs.outlineVariant
    }
    val shape = RoundedCornerShape(14.dp)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .clickable(enabled = !answered, onClick = onClick),
        shape = shape,
        color = container,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text,
            fontSize = 18.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp)
        )
    }
}

@Composable
fun ResultView(
    correct: Int,
    total: Int,
    onRetry: () -> Unit,
    onExit: () -> Unit
) {
    val pct = if (total == 0) 0 else correct * 100 / total
    val title = when {
        pct >= 80 -> "Excellent!"
        pct >= 60 -> "Good job!"
        else -> "Keep going!"
    }
    val note = if (pct >= 60) {
        "You passed. Your progress is saved."
    } else {
        "You need 60% to complete a lesson. Review and try again."
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            if (pct >= 60) "よくできました" else "もう一度",
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.secondary
        )
        Spacer(Modifier.height(8.dp))
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Text("$correct / $total", fontSize = 52.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("$pct%", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Text(
            note,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = onExit,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Done", fontSize = 16.sp)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onRetry,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Try again", fontSize = 16.sp)
        }
    }
}
