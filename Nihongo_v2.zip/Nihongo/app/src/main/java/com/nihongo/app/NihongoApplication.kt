package com.nihongo.app

import android.app.Application

class NihongoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
    }
}
