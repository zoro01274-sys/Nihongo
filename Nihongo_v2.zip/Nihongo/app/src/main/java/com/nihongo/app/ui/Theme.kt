package com.nihongo.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF1F5C4A),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE1F0E8),
    onPrimaryContainer = Color(0xFF0F3A2D),
    secondary = Color(0xFFD94A2B),
    onSecondary = Color(0xFFFFFFFF),
    background = Color(0xFFFAF9F6),
    onBackground = Color(0xFF1B1B1A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1B1A),
    surfaceVariant = Color(0xFFF0EEE8),
    onSurfaceVariant = Color(0xFF6B6B66),
    outline = Color(0xFFC9C6BC),
    outlineVariant = Color(0xFFE6E3DA),
    error = Color(0xFFC0392B),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFBE4E0),
    onErrorContainer = Color(0xFF6E1B12)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7CCBAE),
    onPrimary = Color(0xFF0C2A20),
    primaryContainer = Color(0xFF1F3F34),
    onPrimaryContainer = Color(0xFFCDEBDD),
    secondary = Color(0xFFE8765A),
    onSecondary = Color(0xFF000000),
    background = Color(0xFF121614),
    onBackground = Color(0xFFECEBE6),
    surface = Color(0xFF1A1F1C),
    onSurface = Color(0xFFECEBE6),
    surfaceVariant = Color(0xFF242B27),
    onSurfaceVariant = Color(0xFF9BA59F),
    outline = Color(0xFF3A443F),
    outlineVariant = Color(0xFF2A322D),
    error = Color(0xFFFF8A7A),
    onError = Color(0xFF4A0F08),
    errorContainer = Color(0xFF4A1F1A),
    onErrorContainer = Color(0xFFFFD6D0)
)

@Composable
fun NihongoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
