package com.nihongo.app.data

import com.nihongo.app.AppGraph

data class Question(
    val prompt: String,
    val options: List<String>,
    val answer: Int,
    val sub: String = "",
    val speak: String = "",
    val big: Boolean = false
)

object QuizGen {

    fun inline(en: String, bn: String, lang: String): String = when (lang) {
        "en" -> en
        "bn" -> if (bn.isBlank()) en else bn
        else -> if (bn.isBlank()) en else "$en / $bn"
    }

    fun sentence(en: String, bn: String, lang: String): String = when (lang) {
        "en" -> en
        "bn" -> if (bn.isBlank()) en else bn
        else -> if (bn.isBlank()) en else "$en\n$bn"
    }

    private fun jpLabel(i: Item): String =
        if (i.jp.isBlank() || i.jp == i.kana) i.kana else "${i.jp}  (${i.kana})"

    private fun options(
        correct: String,
        near: List<String>,
        far: List<String>,
        n: Int = 4
    ): Pair<List<String>, Int> {
        val distractors = (near.shuffled() + far.shuffled())
            .filter { it != correct }
            .distinct()
            .take(n - 1)
        val opts = (distractors + correct).shuffled()
        return Pair(opts, opts.indexOf(correct))
    }

    private fun vocabQuestions(items: List<Item>, lang: String): List<Question> {
        val all = AppGraph.vocab
        val farMeaning = all.map { inline(it.en, it.bn, lang) }
        val farJp = all.map { jpLabel(it) }
        val nearMeaning = items.map { inline(it.en, it.bn, lang) }
        val nearJp = items.map { jpLabel(it) }
        val list = ArrayList<Question>()
        items.shuffled().forEachIndexed { idx, item ->
            val meaning = inline(item.en, item.bn, lang)
            if (idx % 2 == 0) {
                val (opts, ans) = options(meaning, nearMeaning, farMeaning)
                list.add(
                    Question(
                        prompt = item.jp,
                        sub = if (item.kana != item.jp) item.kana else "",
                        speak = item.kana,
                        options = opts,
                        answer = ans,
                        big = true
                    )
                )
            } else {
                val (opts, ans) = options(jpLabel(item), nearJp, farJp)
                list.add(Question(prompt = meaning, options = opts, answer = ans))
            }
        }
        return list
    }

    private fun kanjiQuestions(items: List<Item>, lang: String): List<Question> {
        val all = AppGraph.kanji
        val farMeaning = all.map { inline(it.en, it.bn, lang) }
        val farChar = all.map { it.jp }
        val farReading = all.mapNotNull { it.ex.firstOrNull()?.kana }
        val nearMeaning = items.map { inline(it.en, it.bn, lang) }
        val nearChar = items.map { it.jp }
        val nearReading = items.mapNotNull { it.ex.firstOrNull()?.kana }
        val list = ArrayList<Question>()
        items.shuffled().forEachIndexed { idx, item ->
            val meaning = inline(item.en, item.bn, lang)
            val ex = item.ex.firstOrNull()
            when {
                idx % 3 == 1 -> {
                    val (opts, ans) = options(item.jp, nearChar, farChar)
                    list.add(Question(prompt = meaning, options = opts, answer = ans, big = false))
                }
                idx % 3 == 2 && ex != null -> {
                    val (opts, ans) = options(ex.kana, nearReading, farReading)
                    list.add(
                        Question(
                            prompt = ex.jp,
                            sub = "How is this read?",
                            speak = ex.kana,
                            options = opts,
                            answer = ans,
                            big = true
                        )
                    )
                }
                else -> {
                    val (opts, ans) = options(meaning, nearMeaning, farMeaning)
                    list.add(
                        Question(
                            prompt = item.jp,
                            speak = ex?.kana ?: "",
                            options = opts,
                            answer = ans,
                            big = true
                        )
                    )
                }
            }
        }
        return list
    }

    private fun grammarQuestions(items: List<Item>, lang: String): List<Question> {
        val farSentences = AppGraph.examples.map { sentence(it.en, it.bn, lang) }
        val nearSentences = items.flatMap { it.ex }.map { sentence(it.en, it.bn, lang) }
        val list = ArrayList<Question>()
        for (item in items) {
            val q = item.quiz
            if (q != null && q.o.size >= 2) {
                val order = q.o.indices.shuffled()
                val opts = order.map { q.o[it] }
                list.add(Question(prompt = q.q, options = opts, answer = order.indexOf(q.a)))
            }
            for (ex in item.ex.take(2)) {
                val correct = sentence(ex.en, ex.bn, lang)
                val (opts, ans) = options(correct, nearSentences, farSentences)
                list.add(Question(prompt = ex.jp, sub = ex.ro, speak = ex.kana, options = opts, answer = ans))
            }
        }
        return list.shuffled().take(10)
    }

    fun kanaQuestions(chars: List<KanaChar>): List<Question> {
        val valid = chars.filter { it.c.isNotBlank() }
        val unique = valid.filter { v -> valid.count { it.r == v.r } == 1 }
        val list = ArrayList<Question>()
        unique.shuffled().take(10).forEachIndexed { idx, k ->
            val near = valid.filter { it.g == k.g }
            if (idx % 2 == 0) {
                val (opts, ans) = options(k.r, near.map { it.r }, valid.map { it.r })
                list.add(Question(prompt = k.c, speak = k.c, options = opts, answer = ans, big = true))
            } else {
                val (opts, ans) = options(k.c, near.map { it.c }, valid.map { it.c })
                list.add(Question(prompt = k.r, options = opts, answer = ans, big = true))
            }
        }
        return list
    }

    private fun questionsFor(type: String, items: List<Item>, lang: String): List<Question> = when (type) {
        "vocab" -> vocabQuestions(items, lang)
        "kanji" -> kanjiQuestions(items, lang)
        "grammar" -> grammarQuestions(items, lang)
        else -> emptyList()
    }

    fun forLesson(lesson: Lesson, lang: String): List<Question> =
        questionsFor(lesson.type, lesson.items, lang).take(12)

    fun quick(mode: String, lang: String): List<Question> {
        val store = AppGraph.store
        return when (mode) {
            "hira" -> kanaQuestions(AppGraph.course.kana.hiragana)
            "kata" -> kanaQuestions(AppGraph.course.kana.katakana)
            "vocab", "kanji", "grammar" -> {
                val ofType = AppGraph.allLessons.filter { it.type == mode }
                val done = ofType.filter { store.isDone(it.id) }
                val source = if (done.isEmpty()) ofType else done
                val count = if (mode == "grammar") 6 else 10
                val items = source.flatMap { it.items }.shuffled().take(count)
                questionsFor(mode, items, lang)
            }
            else -> emptyList()
        }
    }
}
