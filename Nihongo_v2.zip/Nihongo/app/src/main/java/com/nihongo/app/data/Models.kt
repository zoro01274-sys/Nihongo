package com.nihongo.app.data

import kotlinx.serialization.Serializable

@Serializable
data class Example(
    val jp: String = "",
    val kana: String = "",
    val ro: String = "",
    val en: String = "",
    val bn: String = ""
)

@Serializable
data class QuizDef(
    val q: String = "",
    val o: List<String> = emptyList(),
    val a: Int = 0
)

@Serializable
data class Item(
    val jp: String = "",
    val kana: String = "",
    val ro: String = "",
    val en: String = "",
    val bn: String = "",
    val onyomi: String = "",
    val kunyomi: String = "",
    val ex: List<Example> = emptyList(),
    val quiz: QuizDef? = null
)

@Serializable
data class Lesson(
    val id: String,
    val type: String,
    val en: String,
    val bn: String = "",
    val items: List<Item> = emptyList()
)

@Serializable
data class CourseUnit(
    val id: String,
    val en: String,
    val bn: String = "",
    val lessons: List<Lesson> = emptyList()
)

@Serializable
data class KanaChar(
    val c: String = "",
    val r: String = "",
    val g: String = "",
    val w: String = "",
    val wr: String = "",
    val wm: String = "",
    val wb: String = ""
)

@Serializable
data class KanaSet(
    val hiragana: List<KanaChar> = emptyList(),
    val katakana: List<KanaChar> = emptyList()
)

@Serializable
data class Course(
    val level: String = "N5",
    val kana: KanaSet = KanaSet(),
    val units: List<CourseUnit> = emptyList()
)
